
    const revealTargets = document.querySelectorAll('.hero, .section-block, .contact-section, .footer, .signature-band');

    if ('IntersectionObserver' in window) {
      const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            revealObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

      revealTargets.forEach((el) => {
        el.classList.add('reveal-block');
        revealObserver.observe(el);
      });
    } else {
      revealTargets.forEach((el) => el.classList.add('is-visible'));
    }
  